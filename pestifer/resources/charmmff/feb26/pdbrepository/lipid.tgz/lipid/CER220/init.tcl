# pestifer.scripters: init.tcl
######################## pestifer 3.31.0  seed 27021972 ########################
package require psfgen
psfcontext mixedcase
topology top_all36_prot.rtf
topology top_all36_cgenff.rtf
topology top_all36_lipid.rtf
topology top_all36_carb.rtf
topology top_all36_na.rtf
topology toppar_water_ions.str
topology toppar_all36_carb_glycopeptide.str
topology toppar_all36_carb_imlab.str
topology toppar_all36_prot_modify_res.str
topology toppar_all36_moreions.str
topology toppar_all36_lipid_sphingo.str
topology top_all35_ethers.rtf
pdbalias atom ILE CD1 CD
pdbalias atom MET SE SD
pdbalias atom BGLCNA C7 C
pdbalias atom BGLCNA O7 O
pdbalias atom BGLCNA C8 CT
pdbalias atom BGLCNA N2 N
pdbalias atom ANE5AC C10 C
pdbalias atom ANE5AC C11 CT
pdbalias atom ANE5AC N5 N
pdbalias atom ANE5AC O1A O11
pdbalias atom ANE5AC O1B O12
pdbalias atom ANE5AC O10 O
pdbalias atom AGLCNA C7 C
pdbalias atom AGLCNA O7 O
pdbalias atom AGLCNA C8 CT
pdbalias atom AGLCNA N2 N
pdbalias atom AGALNA C7 C
pdbalias atom AGALNA O7 O
pdbalias atom AGALNA C8 CT
pdbalias atom AGALNA N2 N
pdbalias atom BGALNA C7 C
pdbalias atom BGALNA O7 O
pdbalias atom BGALNA C8 CT
pdbalias atom BGALNA N2 N
pdbalias atom BNE5AC C10 C
pdbalias atom BNE5AC C11 CT
pdbalias atom BNE5AC N5 N
pdbalias atom BNE5AC O1A O11
pdbalias atom BNE5AC O1B O12
pdbalias atom BNE5AC O10 O
pdbalias atom AGLCA O6A O61
pdbalias atom AGLCA O6B O62
pdbalias atom BGLCA O6A O61
pdbalias atom BGLCA O6B O62
pdbalias atom AIDOA O6A O61
pdbalias atom AIDOA O6B O62
pdbalias atom VCG C01 C1
pdbalias atom VCG C02 C2
pdbalias atom VCG C03 C3
pdbalias atom VCG C04 C4
pdbalias atom VCG C05 C5
pdbalias atom VCG C06 C6
pdbalias atom VCG C07 C7
pdbalias atom VCG C08 C8
pdbalias atom VCG C09 C9
pdbalias atom TIP3 O OH2
pdbalias atom CLA CL CLA
pdbalias residue HIS HSD
pdbalias residue MSE MET
pdbalias residue PO4 H2PO4
pdbalias residue H2PO H2PO4
pdbalias residue MAN AMAN
pdbalias residue BMA BMAN
pdbalias residue NAG BGLCNA
pdbalias residue NDG AGLCNA
pdbalias residue FUC AFUC
pdbalias residue FUL BFUC
pdbalias residue GAL BGAL
pdbalias residue BGC BGLC
pdbalias residue XYP BXYL
pdbalias residue GLC AGLC
pdbalias residue A2G AGALNA
pdbalias residue NGA BGALNA
pdbalias residue XYS AXYL
pdbalias residue RAM ARHM
pdbalias residue RM4 BRHM
pdbalias residue GCU AGLCA
pdbalias residue BDP BGLCA
pdbalias residue IDR AIDOA
pdbalias residue SLB BNE5AC
pdbalias residue SIA ANE5AC
pdbalias residue ANE5 ANE5AC
pdbalias residue EIC LIN
pdbalias residue HOH TIP3
pdbalias residue ZN ZN2
pdbalias residue CL CLA
pdbalias residue C6DH C6DHPC
pdbalias residue C7DH C7DHPC
pdbalias residue DT THY
pdbalias residue DA ADE
pdbalias residue DC CYT
pdbalias residue DG GUA
pdbalias residue DU URA
pdbalias residue HEM HEME
pdbalias residue TOCL TOCL1
segment A {
    first none
    last none
    resid 1 CER220 A
}
psfset coord A 1 C17S {0 0 0}
psfset coord A 1 C18S {1.53090 0 0}
set a [expr 113.23*acos(-1.0)/180.0]
set x [expr 1.5309*cos($a)]
set y [expr 1.5309*sin($a)]
psfset coord A 1 C16S [list $x $y 0.0]
guesscoord
regenerate angles dihedrals
writepsf cmap CER220-init.psf
writepdb CER220-init.pdb
exit
########################### END PESTIFER VMD SCRIPT ############################
######################## Thank you for using Pestifer! #########################
